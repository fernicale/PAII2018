package modelo;

/**
 *
 * @author Chigal, Lautaro - Ferrazzuolo, Nicolas
 */

public class Provincia {

    private final String nombre;

    public Provincia(String nombre) {
        this.nombre = nombre;
    }
    
}
