package modelo;

/**
 *
 * @author Chigal, Lautaro - Ferrazuolo, Nicolas
 */

public class Sesion {
    
    private String usuario, clave;

    public Sesion(String usuario, String clave) {
        this.usuario = usuario;
        this.clave = clave;
    }
    
}
