package modelo;

/**
 *
 * @author Chigal, Lautaro - Ferrazuolo, Nicolas
 */

public class Pais {
    
    private final String nombre;

    public Pais(String nombre) {
        this.nombre = nombre;
    }
    
}
